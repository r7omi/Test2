# Blossom Blade

An original 2D samurai boss-rush for Android (Godot 4.3+). Three oni bosses, all art drawn in code, no assets to import.

## Controls
| Action | Touch | Keyboard (testing) |
|---|---|---|
| Move | `<` `>` buttons | Arrow keys / A D |
| Jump | JUMP | Space / W |
| Slash | SLASH | Z / J |
| Parry | PARRY | X / K |

- Slash cuts incoming petals and hurts bosses.
- Press PARRY just before a hit lands: it negates the damage, stuns the boss and reflects petals.
- Beating a boss restores 2 hearts.

## Build the APK
1. Install **Godot 4.3 or newer** (standard version) from godotengine.org.
2. Install **JDK 17** and the **Android SDK** (easiest: Android Studio, then SDK Manager -> install Platform-Tools, Build-Tools 34, Platform 34, Command-line Tools, CMake).
3. In Godot: **Editor -> Editor Settings -> Export -> Android**, set the Android SDK path and JDK path, and the debug keystore (Godot can generate one: `keytool -genkey -v -keystore debug.keystore -alias androiddebugkey -storepass android -keypass android -keyalg RSA -validity 10000 -dname "CN=Android Debug,O=Android,C=US"`).
4. **Editor -> Manage Export Templates -> Download and Install**.
5. Open this folder via **Import** (select `project.godot`).
6. **Project -> Export -> Add... -> Android**, then **Export Project** and save as `BlossomBlade.apk` (turn off "Export With Debug" only when you have a release keystore).
7. Copy the APK to your phone and install it (allow "install unknown apps"), or plug the phone in with USB debugging and use the one-click Android button at the top right of Godot.

## Tweaking
Everything is in `main.gd`: boss HP (`BOSS_HP`), names and colors at the top, attack timings in `_pick_attack` / `_run_attack`.

## Easiest: let GitHub build the APK for you
1. Create a free GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the repo's **Actions** tab, pick **Build Android APK**, press **Run workflow**.
3. When it finishes (about 5 minutes), download **BlossomBlade-apk** from the run page, unzip it, and install `BlossomBlade.apk` on your phone.
